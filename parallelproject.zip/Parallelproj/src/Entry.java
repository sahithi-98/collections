import java.math.BigDecimal;
import java.util.Scanner;

import com.cg.mypaymentapp.repo.WalletRepo;
import com.cg.mypaymentapp.repo.WalletRepoImpl;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImp;

public class Entry {
	public static void main(String[] args) {
		int choice;
		int choice1 = 0;
		String name, mobileno;
		BigDecimal amount;
		Scanner sc = new Scanner(System.in);
		WalletService ws = new WalletServiceImp();
		WalletRepo wr=new WalletRepoImpl();
		do {
			System.out.println("Enter the choice:");

			System.out.println("1.create\n 2.show balance\n 3.fund transfer\n 4.deposit\n 5.withdrawl\n ");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("enter name:");
				name = sc.next();
				System.out.println("Enter mobileno:");
				mobileno = sc.next();
				System.out.println("Enter amount:");
				amount = sc.nextBigDecimal();
				ws.createAccount(name, mobileno,amount);
				
				break;
			case 2:
				System.out.println("Enter mobileno:");
				mobileno = sc.next();
				ws.showBalance(mobileno);
				break;
			case 3:
				System.out.println("Enter Source no:");
				String sourceno = sc.next();

				System.out.println("Enter Targetno:");
				String targetno = sc.next();
				System.out.println("Amount to be transferred");
				amount = sc.nextBigDecimal();
				ws.fundTransfer(sourceno,
						targetno,amount);
				break;

			case 4:
				System.out.println("Enter mobileno");
				mobileno = sc.next();
				System.out.println("Enter amt to be deposited");
				amount= sc.nextBigDecimal();
				ws.depositAmount(mobileno,amount);
				break;

			case 5:
				System.out.println("Enter mobileno");
				mobileno = sc.next();
				System.out.println("Enter amt to be withdraw");
				amount = sc.nextBigDecimal();
				ws.withdrawAmount(mobileno,amount);
				break;
			case 6:
				System.out.println("Enter mobileno");
				mobileno = sc.next();
				wr.findOne(mobileno);
		
				

			}
		} while (choice1 != 1);
	}
}
