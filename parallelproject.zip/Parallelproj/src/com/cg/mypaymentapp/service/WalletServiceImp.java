package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.repo.WalletRepo;
import com.cg.mypaymentapp.repo.WalletRepoImpl;

public class WalletServiceImp implements WalletService {
	static Map<String, Customer> customer = new HashMap<>();
	WalletRepo wr=new WalletRepoImpl();
	

	@Override
	public Customer createAccount(String name, String mobileno, BigDecimal amount) {
		Wallet w = new Wallet(amount);
		Customer c = new Customer(name, mobileno, w);
		boolean status=wr.save(c);
		return c;
		
		//customer.put(mobileno, c);
		//System.out.println("" + c);

	}

	@Override
	public Customer showBalance(String mobileno) {

		if (customer.containsKey(mobileno)) {

			System.out.println("Bal is" + customer.get(mobileno).getWallet().getBalance());
		} else {
			System.out.println("invalid");
		}
		return null;
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		if (customer.containsKey(sourceMobileNo) && customer.containsKey(targetMobileNo)) {
			BigDecimal bd = customer.get(sourceMobileNo).getWallet().getBalance();
			bd = bd.subtract(amount);

			BigDecimal bd1 = customer.get(targetMobileNo).getWallet().getBalance();
			bd1 = bd1.add(amount);
			customer.get(sourceMobileNo).getWallet().setBalance(bd);
			customer.get(targetMobileNo).getWallet().setBalance(bd1);
			System.out.println(customer.get(sourceMobileNo).getWallet().getBalance());
			System.out.println(customer.get(targetMobileNo).getWallet().getBalance());
		} else {
			System.out.println("invalid");
		}

		return null;
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		if (customer.containsKey(mobileNo)) {
			BigDecimal bd = customer.get(mobileNo).getWallet().getBalance();
			bd = bd.add(amount);
			customer.get(mobileNo).getWallet().setBalance(bd);
			System.out.println(customer.get(mobileNo).getWallet().getBalance());
		} else {
			System.out.println("invalid");
		}
		return null;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		if (customer.containsKey(mobileNo)) {
			BigDecimal bd = customer.get(mobileNo).getWallet().getBalance();
			bd = bd.subtract(amount);
			customer.get(mobileNo).getWallet().setBalance(bd);
			System.out.println(customer.get(mobileNo).getWallet().getBalance());
		} else {
			System.out.println("invalid");
		}

		return null;
	}

	@Override
	public Map<String, Customer> findAll() {
		// TODO Auto-generated method stub
		return customer;
	}

}
