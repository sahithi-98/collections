package com.cg.mypaymentapp.repo;

import java.math.BigDecimal;
import java.util.Map;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImp;

public class WalletRepoImpl implements WalletRepo {
Map<String,Customer> rep;
	@Override
	public boolean save(Customer customer) {
		WalletService service=new WalletServiceImp();
		rep=service.findAll();
		rep.put(customer.getMobileNo(), customer);		
		return true;
	}

	@Override
	public Customer findOne(String mobileNo) {
		if(rep.containsKey(mobileNo))
		{
			BigDecimal am=rep.get(mobileNo).getWallet().getBalance();
			String name=rep.get(mobileNo).getName();
			Wallet w=new Wallet(am);
			Customer c=new Customer(name,mobileNo,w);
			return c;
		}
		else
		{
			return null;
		}
		
	}

}
